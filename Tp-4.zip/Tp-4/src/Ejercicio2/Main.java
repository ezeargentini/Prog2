package Ejercicio2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            double n;
            int posicion;
            String cadena;
            double[] valores = {9.83, 4.5, -3.06, 0.06, 2.52, -11.3, 7.60, 3.00, -30.4, 105.2};
            System.out.println("Contenido del array antes de modificar:");
            for (int i = 0; i < valores.length; i++) {
                try{
                    System.out.printf("%.2f ", valores[i]);
                }catch (ArrayIndexOutOfBoundsException e){
                    System.out.println("Error: indice fuera de rango del vector");
                }

            }
            try {
                System.out.print("\n\nIntroduce la posición del array a modificar: ");
                cadena = sc.nextLine();
                posicion = Integer.parseInt(cadena);
                try {
                    System.out.print("\nIntroduce el nuevo valor de la posición " + posicion + ": ");
                    n = sc.nextDouble();
                    valores[posicion] = n;
                    System.out.println("\nPosición modificada: " + posicion);
                    System.out.println("Nuevo valor: " + n);
                } catch (NumberFormatException e) {
                    System.out.println("Debe ingresar un número");
                }
            } catch (NumberFormatException e) {
                System.out.println("No ingresó una posición numérica.");
            }


            System.out.println("Contenido del array modificado:");
                for (int i = 0; i < valores.length; i++) {
                    try{
                        System.out.printf("%.2f ", valores[i]);
                    }catch (ArrayIndexOutOfBoundsException e){
                        System.out.println("Error: indice fuera de rango.");
                    }

                }

        }
}
