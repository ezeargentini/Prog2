package Ejercicio3;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        double heigth, area, base;

        try{
            System.out.println("Ingrese la altura del triangulo");
            heigth = read.nextDouble();
            System.out.println("Ingrese la base del triangulo");
            base = read.nextDouble();
            area = (base * heigth) / 2;
            System.out.println("El area del triangulo es: " + area);
        }catch (InputMismatchException e){
            System.out.println("Debe ingresar numeros enteros o decimales");
        }
    }
}
