package Ejercicio1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        int numberRandom = (int) (Math.random() * 100) + 1;
        int tries = 0;
        int numberUser = 0;
        System.out.println(numberRandom);
        do{
            try{
                System.out.println("Ingrese el numero");
                numberUser = read.nextInt();
                tries++;
                if(numberRandom < numberUser){
                    System.out.println("Ingreso un numero mayor! Intente nuevamente.");
                }else if(numberRandom > numberUser){
                    System.out.println("Ingreso un numero menor! Intente nuevamente");
                }
            }catch (InputMismatchException e){
                System.out.println("Debe ingresar un numero entero. Intente nuevamente!");
            }

        }while (numberRandom != numberUser);
        System.out.println("Felicitaciones!!! adivino el numero: " + numberRandom);
        System.out.println("Ocupo " + tries + " intentos");
    }
}
