package Ejercicio2;

public class Main {
    public static void main(String[] args) {

        Employee supervisor = new Employee("Supervisor 1");
        Employee employee = new Employee("Empleado con supervisor");
        Employee employee1 = new Employee("Empleado sin supervisor");

        employee.asignarSupervisor(supervisor);
        System.out.println("Nombre del supervisor: " + employee.obtenerNombreDelSupervisor());
        System.out.println("Nombre del supervisor: " + employee1.obtenerNombreDelSupervisor());
    }
}
