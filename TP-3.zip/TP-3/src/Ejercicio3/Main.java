package Ejercicio3;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> dayOfTheWeek = new ArrayList<>();
        dayOfTheWeek.add("Lunes");
        dayOfTheWeek.add("Martes");
        dayOfTheWeek.add("Miercoles");
        dayOfTheWeek.add("Jueves");
        dayOfTheWeek.add("Viernes");
        dayOfTheWeek.add("Sabado");
        dayOfTheWeek.add("Domingo");

        dayOfTheWeek.add(4, "Juernes");

        System.out.println("Elemento posicion 4: " + dayOfTheWeek.get(3));
        System.out.println("Elemento posicion 4: " + dayOfTheWeek.get(4));

        dayOfTheWeek.remove("Juernes");

        for (String position : dayOfTheWeek) {
            System.out.println("Dia: " + position);
        }

        for (String position : dayOfTheWeek) {
            if (position.equals("Lunes")) {
                System.out.println("El dia Lunes esta en la lista");
            }
        }


        for (String position : dayOfTheWeek) {
            if (position.equalsIgnoreCase("Lunes")) {
                System.out.println("LUNES, lunes o Lunes estan en la lista");
            }
        }

        dayOfTheWeek.clear();
        System.out.println("Se eliminaron los elementos de la lista quedaron: " + dayOfTheWeek.size() + " elementos");

    }
}
