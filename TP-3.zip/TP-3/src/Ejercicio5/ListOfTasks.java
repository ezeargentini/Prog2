package Ejercicio5;

import java.util.*;

public class ListOfTasks implements Iterable<Task> {
    private ArrayList<Task> tasks = new ArrayList<>();

    public void addTask(){
        Scanner read = new Scanner(System.in);
        Task task = new Task();
        System.out.println("Ingrese la descripcion de la tarea:");
        task.setDescription(read.nextLine());
        System.out.println("Ingrese la prioridad de la tarea en numeros");
        task.setPriority(read.nextInt());
        tasks.add(task);
    }

    public void deleteTask(){
        Scanner read = new Scanner(System.in);
        String descriptionDelete;
        int initialSizeTasks = tasks.size();
        System.out.println("Ingrese la descripcion de la tarea");
        descriptionDelete = read.nextLine();
        for (int i = 0; i < tasks.size(); i++) {
            if(tasks.get(i).getDescription().equalsIgnoreCase(descriptionDelete)){
                tasks.remove(i);
            }
        }
        if(initialSizeTasks == tasks.size()){
            System.out.println("No se encontro una tarea con la descripcion" + descriptionDelete);
        }
    }

    public int quantumTaks(){
        return tasks.size();
    }

    public void descendingOrder(ArrayList<Task> unorderedTasks){
        for (int i = 0; i < tasks.size() - 1; i++) {
            for (int j = 0; j < tasks.size() - 1 -i; j++) {
                if(tasks.get(j).getPriority() > tasks.get(j + 1).getPriority()){
                    Task temporalTask = tasks.get(j);
                    tasks.set(j, tasks.get(j+1));
                    tasks.set(j + 1, temporalTask);
                }
            }
        }
    }

    public void displayTasksDesending(){
        descendingOrder(tasks);
        System.out.println("-- Lista de tareas ordenadas en prioridad descendente ---");
        for (Task task : tasks) {
            System.out.println("Prioridad: " + task.getPriority());
            System.out.println("Descripicion: " + task.getDescription());
        }
    }

    //Implementacion interfaz iterable
    public Iterator<Task> iterator() {
        return new TaskIterator(tasks);
    }

    public static class TaskIterator implements Iterator<Task>{
        private List<Task> tasks;
        private int indexActual = 0;

        public TaskIterator(List<Task> tasks) {
            this.tasks = tasks;
        }

        public boolean hasNext(){
            return indexActual < tasks.size();
        }

        public Task next(){
            if (!hasNext()) {
                throw new IndexOutOfBoundsException("No hay más elementos en la lista");
            }
            Task task = tasks.get(indexActual);
            indexActual++;
            return task;
        }
    }
}
