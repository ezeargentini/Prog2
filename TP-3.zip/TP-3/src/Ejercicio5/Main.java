package Ejercicio5;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        ListOfTasks listOfTasks = new ListOfTasks();
        int option = 0;

        do {
            System.out.println("--- Ingrese una opcion ---");
            System.out.println("1. Agregar tarea");
            System.out.println("2. Mostrar tareas, ordenadas por prioridad");
            System.out.println("3. Eliminar tarea");
            System.out.println("0. Salir del programa");
            option = read.nextInt();

            switch (option){
                case 1:
                    listOfTasks.addTask();
                    break;
                case 2:
                    listOfTasks.displayTasksDesending();
                    break;
                case 3:
                    listOfTasks.deleteTask();
                    break;
                case 0:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("No ingreso una opcion correcta");
                    break;
            }
        }while (option != 0);
    }
}
