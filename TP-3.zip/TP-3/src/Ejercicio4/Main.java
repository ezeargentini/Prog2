package Ejercicio4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        StudentsService service = new StudentsService();
        int option = 0;

        do{
            System.out.println("Ingrese una opcion");
            System.out.println("1. Añadir alumno");
            System.out.println("2. Mostar todos los alumnos");
            System.out.println("3. Calcular el promedio de notas de los alumnos");
            System.out.println("4. Mostrar el alumno con la nota mas alta");
            System.out.println("5. Buscar un alumno por nombre");
            System.out.println("0. salir");
            option = read.nextInt();

            switch (option){
                case 1:
                    service.addStudent();
                    break;
                case 2:
                    service.displayStudents();
                    break;
                case 3:
                    service.averageNotes();
                    break;
                case 4:
                    service.studentMost();
                    break;
                case 5:
                    service.searchStudent();
                    break;
                case 0:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println(option + " no es una opcion correcta");
                    break;
            }
        }while (option != 0);
    }
}
