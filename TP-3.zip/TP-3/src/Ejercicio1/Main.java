package Ejercicio1;

import Ejercicio1.Class.Group;
import Ejercicio1.Class.School;
import Ejercicio1.Class.Subject;
import Ejercicio1.Class.Teacher;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);

        //Declaramos arrayList para facilitar el uso de los metodos
        ArrayList<Teacher> teachers = new ArrayList<>();
        ArrayList<Subject> subjects = new ArrayList<>();

        //Declaramos un grupo
        Group group = new Group('A');

        //Decalaramos profesores y agregamos a la lista
        Teacher teacher = new Teacher(44820614,"Profesor 0", "Matematicas");
        Teacher teacher1 = new Teacher(44820614,"Profesor 1", "Ciencias");
        Teacher teacher2 = new Teacher(44820614,"Profesor 2", "Ciencias");
        teachers.add(teacher);
        teachers.add(teacher1);
        teachers.add(teacher2);

        //Declaramos asgnaturas y agregamos a la lista
        Subject subject = new Subject(teacher,"Matematica I",3,12,group);
        Subject subject1 = new Subject(teacher,"Ciencias I",1, 13.5F,group);
        Subject subject2 = new Subject(teacher,"Ciencias II",1, 10.5F,group);
        Subject subject3 = new Subject(teacher,"Ciencias III",1, 9.5F,group);
        subjects.add(subject);
        subjects.add(subject1);
        subjects.add(subject2);
        subjects.add(subject3);

        //Creamos una escuela para usar los metodos
        School school = new School();

        //Añadimos asignaturas al grupo
        group.addSubject(subject);
        group.addSubject(subject1);
        group.addSubject(subject2);

        //Añadimos asgnaturas al profesor
        teacher.addSubject(subject);
        teacher1.addSubject(subject1);
        teacher2.addSubject(subject1);
        teacher2.addSubject(subject2);
        teacher2.addSubject(subject3);

        //Variables para pedir los nombres en el bucle utilizamos los 3 nombres para hacer el codigo mas legible
        String subjectName;
        String teacherName;
        String studentName;

        //Variable para saber si se encontro el nombre pedido
        boolean found;

        //variable para salir del bucle while
        String exit = "no";

        //Bucle while
        while (exit.equalsIgnoreCase("no")){

            //Menu
            System.out.println("----- Ingrese una opcion ----");
            System.out.println("1. Mostrar la tercer Asginatura de un profesor");
            System.out.println("2. Mostrar todas las asignaturas de un profesor");
            System.out.println("3. Mostrar los alumnos de una asignatura");
            System.out.println("4. Mostrar las asignaturas del primer grupo de un alumno");
            System.out.println("5. Mostrar profesor desde la asignatura de un alumno");
            System.out.println("6. Mostrar los alumnos de la segunda asignatura de un profesor");
            int optionMenu = read.nextInt();
            read.nextLine(); //Consumimos linea del nextInt

            //Condicional switch
            //Todas las opciones del condicional switch utilizan la misma logica explicamos sobre opcion 1
            switch (optionMenu){
                case 1:
                    System.out.println("Ingrese el nombre del profesor"); // Pedimos el nombre del objeto que necesitamos
                    teacherName = read.nextLine();  // Lo leemos
                    found = false; // Iniciamos la variable booleana en falso
                    for (int i = 0; i < teachers.size(); i++) { // Recorremos el array necesario
                        if (teachers.get(i).getName().equalsIgnoreCase(teacherName)){ // Verificamos si esta el nombre que ingreso el usuario
                            school.displayThirdSubject(teachers.get(i)); // En el caso de estar llamamos al metodo de school
                            found = true; // y cambiamos nuestra bandera a true ya que lo encontramos
                            break; // Salimos del bucle ya que lo encontramos
                        }
                    }
                    if (!found){ // en el caso de no encontrarlo mostramos un mensaje por pantalla
                        System.out.println("Nombre del profesor no valido");
                    }
                    break; // Salimos de la opcion
                case 2:
                    System.out.println("Ingrese el nombre del profesor");
                    teacherName = read.nextLine();
                    found = false;
                    for (int i = 0; i < teachers.size(); i++) {
                        if (teachers.get(i).getName().equalsIgnoreCase(teacherName)){
                            school.displaySubjects(teachers.get(i));
                            found = true;
                            break;
                        }
                    }
                    if (!found){
                        System.out.println("Nombre del profesor no valido");
                    }
                    break;

                case 3:
                    System.out.println("Ingrese el nombre de la asignatura");
                    subjectName = read.nextLine();
                    found = false;
                    for (int i = 0; i < subjects.size(); i++) {
                        if (subjects.get(i).getName().equalsIgnoreCase(subjectName)){
                            school.displayGroup(subjects.get(i));
                            found = true;
                            break;
                        }
                    }
                    if(!found){
                        System.out.println("Asignatura no encontrada");
                    }
                    break;
                case 4:
                    System.out.println("Ingrese el nombre del alumno");
                    studentName = read.nextLine();
                    found = false;
                    for (int i = 0; i < group.getStudents().size(); i++) {
                        if (group.getStudents().get(i).getName().equalsIgnoreCase(studentName)){
                            school.displaySubjectFirstGoupForStudent(group.getStudents().get(i));
                            found = true;
                            break;
                        }
                    }
                    if(!found){
                        System.out.println("Alumno no encontrado");
                    }
                    break;

                case 5:
                    System.out.println("Ingrese el nombre del alumno");
                    studentName = read.nextLine();
                    found = false;
                    for (int i = 0; i < group.getStudents().size(); i++) {
                        if (group.getStudents().get(i).getName().equalsIgnoreCase(studentName)){
                            school.displayTeacherForSubject(group.getStudents().get(i));
                            found = true;
                            break;
                        }
                    }
                    if(!found){
                        System.out.println("Alumno no encontrado");
                    }
                    break;
                case 6:
                    System.out.println("Ingrese el nombre del profesor");
                    teacherName = read.nextLine();
                    found = false;
                    for (int i = 0; i < teachers.size(); i++) {
                        if (teachers.get(i).getName().equalsIgnoreCase(teacherName)){
                            school.displayStudentsForSecondSubject(teachers.get(i));
                            found = true;
                            break;
                        }
                    }
                    if (!found){
                        System.out.println("Nombre del profesor no valido");
                    }
                    break;
                default:
                    System.out.println("No ingreso una opcion correcta");
                    break;
            }
            System.out.println("Desea salir? (si/no)");
            exit = read.nextLine();
        }

        System.out.println("Salio del programa!!!");
    }
}