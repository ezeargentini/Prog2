package Ejercicio1.Class;

import java.util.ArrayList;

public class Teacher extends Person{
    private String department;
    private ArrayList<Subject> subjects = new ArrayList<>();

    public Teacher(int id, String name, String department) {
        super(id, name);
        this.department = department;
    }

    public Teacher(String department) {
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public ArrayList<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(ArrayList<Subject> subjects) {
        this.subjects = subjects;
    }
    public void addSubject(Subject subject){
        subjects.add(subject);
    }
}
