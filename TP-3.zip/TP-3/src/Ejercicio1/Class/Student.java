package Ejercicio1.Class;

import java.util.ArrayList;

public class Student extends Person{
    ArrayList<Group> groups;
    public Student() {
    }

    public Student(int id, String name) {
        super(id, name);
        this.groups = new ArrayList<>();
    }

    public ArrayList<Group> getGroups() {
        return groups;
    }

    public void setGroups(ArrayList<Group> groups) {
        this.groups = groups;
    }

}
