package Ejercicio1.Class;

import java.util.ArrayList;
import java.util.Scanner;

public class Group {
    private ArrayList<Subject> subjects = new ArrayList<>();
    private char letter;
    private ArrayList<Student> students = new ArrayList<>();

    public Group() {
    }

    public Group(char letter) {
        this.letter = letter;
        this.students = addStudent();
    }

    public ArrayList<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(ArrayList<Subject> subjects) {
        this.subjects = subjects;
    }

    public char getLetter() {
        return letter;
    }

    public void setLetter(char letter) {
        this.letter = letter;
    }

    public ArrayList<Student> getStudents() {
        return students;
    }

    public void setStudents(ArrayList<Student> students) {
        this.students = students;
    }

    public ArrayList<Student> addStudent(){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de estudiantes que desea añadir al grupo");
        int quantity = read.nextInt();
        for (int i = 0; i < quantity; i++) {
            read.nextLine(); // Consume linea del nextInt
            Student student = new Student();
            System.out.println("Ingrese el nombre del estudiante");
            student.setName(read.nextLine());
            System.out.println("Ingrese el dni del estudiante");
            student.setId(read.nextInt());

            if(student.getGroups() == null){
                student.setGroups(new ArrayList<>());
            }

            if (!student.getGroups().isEmpty()){
                student.getGroups().add(this);
            }else{
                student.getGroups().add(0,this);
            }
            students.add(student);
        }
        return students;
    }

    public void addSubject(Subject subject){
        subjects.add(subject);
    }
}
