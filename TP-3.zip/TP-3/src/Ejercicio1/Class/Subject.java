package Ejercicio1.Class;

public class Subject {
    private Teacher teacher;
    private String name;
    private int Classroom;
    private float hour;
    private Group group;

    public Subject() {
    }

    public Subject(Teacher teacher, String name, int classroom, float hour, Group group) {
        this.teacher = teacher;
        this.name = name;
        Classroom = classroom;
        this.hour = hour;
        this.group = group;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getClassroom() {
        return Classroom;
    }

    public void setClassroom(int classroom) {
        Classroom = classroom;
    }

    public float getHour() {
        return hour;
    }

    public void setHour(float hour) {
        this.hour = hour;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }
}
