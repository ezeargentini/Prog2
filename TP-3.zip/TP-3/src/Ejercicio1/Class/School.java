package Ejercicio1.Class;

import java.util.Scanner;

public class School {

    //a. Teniendo un objeto de Profesor, muestre el aula de la 3ra. asignatura.
    public void displayThirdSubject(Teacher teacher){
        if(teacher.getSubjects().size() >= 3 && teacher.getSubjects().get(2) != null){
            System.out.println("El aula de la asignatura 3(" + teacher.getSubjects().get(2).getName() +") es: " +teacher.getSubjects().get(2).getClassroom());
        }else{
            System.out.println("No hay ninguna asignatura en la tercera posicion");
        }
    }

    //b. Teniendo un profesor, muestre todos los nombres de las asignaturas que imparte
    public void displaySubjects(Teacher teacher){
        System.out.println("Profesor: " + teacher.getName());
        System.out.println(" ---- Asignaturas ----");
        for (int i = 0; i < teacher.getSubjects().size(); i++) {
            System.out.println("Nombre: " + teacher.getSubjects().get(i).getName() );
        }
    }

    //c. Teniendo una asignatura, muestre nombre y dni de los alumnos del grupo que recibe
    public void displayGroup(Subject subject){
        System.out.println("Asignatura: " + subject.getName());
        System.out.println("---- Alumnos ----");
        for (int i = 0; i < subject.getGroup().getStudents().size(); i++) {
            System.out.println("Nombre: " + subject.getGroup().getStudents().get(i).getName());
            System.out.println("Dni: " +subject.getGroup().getStudents().get(i).getId());
        }
    }

    //e. Teniendo un alumno, muestre todas las asignaturas recibidas por el 1er. grupo al que
    //pertenece.
    public void displaySubjectFirstGoupForStudent(Student student){
        System.out.println("Alumno: " + student.getName());
        System.out.println("---- Asignaturas ----");
        for (int i = 0; i < student.getGroups().get(0).getSubjects().size(); i++) {
            System.out.println("Nombre: " + student.getGroups().get(0).getSubjects().get(i).getName());
        }
    }

    //f. Teniendo un objeto de Alumno y, pidiendo por pantalla, una asignatura existente, muestre
    //desde él, el profesor que la imparte.
    public void displayTeacherForSubject(Student student){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese la asignatura");
        String subjectName = read.nextLine();
        boolean foundSubject = false;
        for (int i = 0; i < student.getGroups().get(0).getSubjects().size(); i++) {
            if (student.getGroups().get(0).getSubjects().get(i).getName().equalsIgnoreCase(subjectName)){ //Vamos a simular que solo hay un grupo, MEJORA PENDIENTE
                foundSubject = true;
                System.out.println("El profesor que dicta la asignatura " + subjectName + " es " +
                        student.getGroups().get(i).getSubjects().get(i).getTeacher().getName());
            }
        }
        if (!foundSubject){
            System.out.println("No se encontro la asignatura");
        }
    }

    //g. Teniendo un objeto de Profesor, muestre los nombres de todos los alumnos inscriptos en el
    //Grupo de la 2da. Asignatura.
    public void displayStudentsForSecondSubject(Teacher teacher){
        if(teacher.getSubjects().size() >= 2){
            System.out.println("Teacher: " + teacher.getName());
            System.out.println("---- Alumnos de " + teacher.getSubjects().get(1).getName() + " ----");
            for (int i = 0; i < teacher.getSubjects().get(1).getGroup().getStudents().size(); i++) {
                System.out.println("Nombre: " + teacher.getSubjects().get(1).getGroup().getStudents().get(i).getName());
            }
        } else {
            System.out.println("El profesor tiene menos de 2 asignturas");
        }

    }

    //h. Responda: ¿En qué se diferencian una asociación de una composición y de una agregación?
    //Una relacion de composicion es que un objeto se relacion dependientemente de otro y en la de agragcion no dependo sino que se agrega en caso de ser necesario
}
