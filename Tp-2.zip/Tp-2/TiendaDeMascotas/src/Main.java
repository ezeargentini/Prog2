import Class.*;

public class Main {
    public static void main(String[] args) {
        Dog dog1 =  new Dog(4,"Luna",12000,"Canino","Labrador",true);
        Dog dog2 = new Dog(12,"Perrito",70000,"Canino","Ovejero",true);
        Cat cat = new Cat(4,"Mishi",1000,"Felino","Sin raza",false);
        Bird bird = new Bird(1,"Pajaro",2000,"Ave","Loro",true);
        Fish fish =  new Fish(2,"Pescado",1000,"Pez","Gurami enano", false);
        PetStore store = new PetStore();

        /* Añadimos animales a la lista */
        store.addAnimals(dog1);
        store.addAnimals(dog2);
        store.addAnimals(cat);
        store.addAnimals(bird);
        store.addAnimals(fish);

        /* Mostramos la lista de animales */
        store.listAnimals();

        /* Alimentamos a 2 aniamles */
        store.feedAnimals(cat.getName());
        store.feedAnimals(bird.getName());

        /* Vendemos 2 animales */
        store.sellAnimals(dog2.getName());
        store.sellAnimals(fish.getName());

        /* Mostramos nuevamente la lista para verificar que se vendieron los animales */
        store.listAnimals();

    }
}