package Class;

public class Cat extends Animal{
    private String breed;
    private boolean stirilized;

    public Cat(int age, String name, double price, String typeAnimal, String breed, boolean stirilized) {
        super(age, name, price, typeAnimal);
        this.breed = breed;
        this.stirilized = stirilized;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public boolean isStirilized() {
        return stirilized;
    }

    public void setStirilized(boolean stirilized) {
        this.stirilized = stirilized;
    }

    @Override
    public String toString() {
        return  "Cat{" + super.toString() +
                "breed='" + breed + '\'' +
                ", stirilized=" + stirilized +
                '}';
    }
}
