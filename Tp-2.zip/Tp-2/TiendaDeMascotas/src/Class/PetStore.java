package Class;

import java.util.ArrayList;

public class PetStore {
    ArrayList<Animal> animals = new ArrayList<>();
    public void addAnimals(Animal animal){
        animals.add(animal);
        System.out.println("El " + animal.getTypeAnimal() + " " + animal.getName() + " se añadio con exito a la lista");
    }

    public void feedAnimals(String name){
        for (int i = 0; i < animals.size(); i++) {
            if (animals.get(i).getName().equalsIgnoreCase(name)){
                animals.get(i).toFeed(name);
            }
        }
    }

    public void sellAnimals(String name){
        for (int i = 0; i < animals.size(); i++) {
            if (animals.get(i).getName().equalsIgnoreCase(name)){
                animals.remove(i);
                System.out.println("El animal se vendio exitosamente!");
            }
        }
    }

    public void listAnimals(){
        System.out.println("El listado de animales es:");
        System.out.println("--------------------------");
        for (int i = 0; i < animals.size(); i++) {
            System.out.println(animals.get(i).toString());
            System.out.println();
        }
    }
}
