package Class;

public class Animal {
    private int age;
    private String name;
    private double price;
    private String typeAnimal;

    public Animal() {
    }

    public Animal(int age, String name, double price, String typeAnimal) {
        this.age = age;
        this.name = name;
        this.price = price;
        this.typeAnimal = typeAnimal;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTypeAnimal() {
        return typeAnimal;
    }

    public void setTypeAnimal(String typeAnimal) {
        this.typeAnimal = typeAnimal;
    }

    public void toFeed(String name){
        System.out.println(name + " se alimentó");
    }

    @Override
    public String toString() {
        return "age=" + age +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", typeAnimal='" + typeAnimal ;
    }
}
