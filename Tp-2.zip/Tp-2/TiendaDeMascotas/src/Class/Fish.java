package Class;

public class Fish extends Animal{
    private String specie;
    private boolean fins;

    public Fish(int age, String name, double price, String typeAnimal, String specie, boolean fins) {
        super(age, name, price, typeAnimal);
        this.specie = specie;
        this.fins = fins;
    }

    public String getSpecie() {
        return specie;
    }

    public void setSpecie(String specie) {
        this.specie = specie;
    }

    public boolean isFins() {
        return fins;
    }

    public void setFins(boolean fins) {
        this.fins = fins;
    }

    @Override
    public String toString() {
        return "Fish{" + super.toString() +
                "specie='" + specie + '\'' +
                ", fins=" + fins +
                '}';
    }
}
