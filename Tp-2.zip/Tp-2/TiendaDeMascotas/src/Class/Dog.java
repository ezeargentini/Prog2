package Class;

public class Dog extends Animal{
    private String breed;
    private boolean vaccinated;

    public Dog(int age, String name, double price, String typeAnimal, String breed, boolean vaccinated) {
        super(age, name, price, typeAnimal);
        this.breed = breed;
        this.vaccinated = vaccinated;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public boolean isVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }

    @Override
    public String toString() {
        return  "Dog{" + super.toString() +
                "breed='" + breed + '\'' +
                ", vaccinated=" + vaccinated +
                '}';
    }
}
