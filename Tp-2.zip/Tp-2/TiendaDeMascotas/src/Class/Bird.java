package Class;

public class Bird extends Animal{
    private String specie;
    private boolean speek;

    public Bird(int age, String name, double price, String typeAnimal, String specie, boolean speek) {
        super(age, name, price, typeAnimal);
        this.specie = specie;
        this.speek = speek;
    }

    public String getSpecie() {
        return specie;
    }

    public void setSpecie(String specie) {
        this.specie = specie;
    }

    public boolean isSpeek() {
        return speek;
    }

    public void setSpeek(boolean speek) {
        this.speek = speek;
    }

    @Override
    public String toString() {
        return "Bird{" + super.toString() +
                "specie='" + specie + '\'' +
                ", speek=" + speek +
                '}';
    }
}
