package PracticaArreglo;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio4TerminadosEn4 {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();
        ArrayList<Integer> endingIn4 = new ArrayList<>();
        int number;
        for (int i = 0; i < 10; i++) {
            System.out.println("Ingrese un numero: ");
            number = read.nextInt();
            numbers.add(number);
        }

        for (int i = 0; i < numbers.size(); i++) {
            if (numbers.get(i) % 10 == 4){
                endingIn4.add(numbers.get(i));
            }
        }

        System.out.println("Los numeros terminados en 4 son: ");
        for (int i = 0; i < endingIn4.size(); i++) {
            System.out.println(endingIn4.get(i));
        }
    }
}
