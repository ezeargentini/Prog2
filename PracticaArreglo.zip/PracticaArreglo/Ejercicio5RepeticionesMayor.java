package PracticaArreglo;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio5RepeticionesMayor {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();
        int number;
        for (int i = 0; i < 10; i++) {
            System.out.println("Ingrese un numero: ");
            number = read.nextInt();
            numbers.add(number);
        }
        int count = 0;
        int most = numbers.get(0);


        for (int i = 0; i < numbers.size(); i++) {
            if (numbers.get(i) > most){
                most = numbers.get(i);
            }
        }
        for (int i = 0; i < numbers.size(); i++) {
            if(most == numbers.get(i)){
                count++;
            }
        }
        System.out.println("El mayor numero esta repetido "+ count + " veces");
    }
}
