package PracticaArreglo;

import java.util.ArrayList;

public class Ejercicio3Primos100a300 {
    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>();
        int count = 0;
        for (int i = 100; i <= 300 && count < 10; i++) {
            if (isPrime(i)){
                numbers.add(i);
                count++;
            }
        }

        for (int i = 0; i < numbers.size(); i++) {
            System.out.println(numbers.get(i));
        }
    }
    public static boolean isPrime(int number){
        if(number <= 1){
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number) ; i++) {
            if (number % i == 0){
                return false;
            }
        }
        return true;
    }
}
