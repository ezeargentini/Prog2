package Ejercicio1;

public interface Dibujable {
    public String dibujar();
}
