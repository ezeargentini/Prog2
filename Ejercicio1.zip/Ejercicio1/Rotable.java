package Ejercicio1;

public interface Rotable {
    public boolean rotar();
}
