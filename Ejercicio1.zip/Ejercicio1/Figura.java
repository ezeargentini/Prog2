package Ejercicio1;

public interface Figura {
    public float area();

}
