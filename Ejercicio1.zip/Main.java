import Ejercicio1.Circulo;
import Ejercicio1.Cuadrado;

public class Main {
    public static void main(String[] args) {
        Cuadrado c1 = new Cuadrado(4);
        System.out.println("El area del cuadrado es: " + c1.area());
        System.out.println("El cuadrado se roto: " + c1.rotar());
        System.out.println(c1.dibujar());

        Circulo ci1 = new Circulo(8);
        System.out.println("El area del cuadrado es: " + ci1.area());
        System.out.println(ci1.dibujar());
    }
}