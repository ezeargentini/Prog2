package Ejercicio2;

public class Main {
    public static void main(String[] args) {
        Rectangulo r1 = new Rectangulo(10,20);
        Circulo c1 = new Circulo(20);
        Cuadrado ca1 = new Cuadrado(15);
        System.out.println("El area del rectangulo: " + r1.calcularArea());
        System.out.println("El perimetro del rectangulo: " + r1.calcularPerimetro());
        System.out.println("El area del circulo: " + c1.calcularArea());
        System.out.println("El perimetro del circulo: " + c1.calcularPerimetro());
        System.out.println("El area del cuadrado: " + ca1.calcularArea());
        System.out.println("El perimetro del cuadrado: " + ca1.calcularPerimetro());
    }
}
