package Ejercicio2;

public class Cuadrado implements FiguraGeometrica{
    private int lado;

    public Cuadrado(int lado) {
        this.lado = lado;
    }

    public int getLado() {
        return lado;
    }

    public void setLado(int lado) {
        this.lado = lado;
    }

    @Override
    public float calcularArea() {
        return lado*lado;
    }

    @Override
    public float calcularPerimetro() {
        return 4 * lado;
    }
}
