package Ejercicio2;

public interface FiguraGeometrica {
    public float calcularArea();
    public float calcularPerimetro();
}
