package Ejercicio3;

public enum TipoNovela {
    histórica,
    romántica,
    policíaca,
    realista,
    ciencia,
    ficción,
    aventuras;

    }
