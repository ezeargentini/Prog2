package Ejercicio3;

public class Novela extends Libro {
    private TipoNovela tipo;

    public Novela(String titulo, String autor, double precio, TipoNovela tipo) {
        super(titulo, autor, precio);
        this.tipo = tipo;
    }

    public TipoNovela getTipo() {
        return tipo;
    }

    public void setTipo(TipoNovela tipo) {
        this.tipo = tipo;
    }
}
