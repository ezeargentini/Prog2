package Ejercicio3;

public class Main {
    public static void main(String[] args) {
        LibroUniversidadColombia l1 = new LibroUniversidadColombia("Calmar la sed","Charo Ruano",12000,"Comision C", "Facultad tecnologia");
        Novela n1 = new Novela("Alma ata", "Juan Vicente Perez", 22000, TipoNovela.romántica);
        System.out.println(l1.toString());
        System.out.println(n1.toString());
    }
}
