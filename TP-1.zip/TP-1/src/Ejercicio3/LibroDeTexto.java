package Ejercicio3;

public class LibroDeTexto extends Libro{
    private String curso;

    public LibroDeTexto() {
    }

    public LibroDeTexto(String titulo, String autor, double precio, String curso) {
        super(titulo, autor, precio);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

}
