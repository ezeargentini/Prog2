package Ejercicio1;

import Ejercicio1.Employee;

public class Manager extends Employee {
    private String department;

    public Manager() {
    }

    public Manager(String name, int age, float salary, String department) {
        super(name, age, salary);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    public void organizeActivities(){
        System.out.println("Se asigno una actividad para el departamento: " + department);
    }
}
