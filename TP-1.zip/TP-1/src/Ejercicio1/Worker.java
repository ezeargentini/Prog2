package Ejercicio1;

import Ejercicio1.Employee;

public class Worker extends Employee {
    private String area;

    public Worker() {
    }

    public Worker(String name, int age, float salary, String area) {
        super(name, age, salary);
        this.area = area;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
    public void producing(){
        System.out.println("El empleado " + getName() + " esta produciendo en su area (" + area + ")" );
    }
}
