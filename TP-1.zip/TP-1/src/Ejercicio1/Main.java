package Ejercicio1;

public class Main {
    public static void main(String[] args) {
        Manager m1 = new Manager("Jeronimo", 21, 12000, "ventas");
        Worker w1 = new Worker("Felipe", 20, 1400, "Atencion al cliente");
        System.out.println("Los datos del gerente son: ");
        System.out.println("Nombre: " + m1.getName());
        System.out.println("Edad: " + m1.getAge());
        System.out.println("Salario: " + m1.getSalary());
        System.out.println("Departamento: " + m1.getDepartment());
        System.out.println("Implementacion de metodos...");
        m1.working();
        m1.organizeActivities();
        System.out.println("---------");
        System.out.println("Los datos del trabajador son: ");
        System.out.println("Nombre: " + w1.getName());
        System.out.println("Edad: " + w1.getAge());
        System.out.println("Salario: " + w1.getSalary());
        System.out.println("Area: " + w1.getArea());
        System.out.println("Implementacion de metodos...");
        w1.working();
        w1.producing();
    }
}