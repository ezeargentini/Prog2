import java.io.IOException;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        int num1, num2, resultado;
        char operador;
        String exit = "no";

        while (exit.equalsIgnoreCase("no")) {
            try {
                System.out.println("Ingrese el primer numero");
                num1 = read.nextInt();
                System.out.println("Ingrese el segundo numero");
                num2 = read.nextInt();
                System.out.println("Ingrese que operacion desea realizar (+, -, /, *)");
                operador = read.next().charAt(0);

                switch (operador) {
                    case '+':
                        resultado = num1 + num2;
                        System.out.println("Resultado: " + resultado);
                        break;
                    case '-':
                        resultado = num1 - num2;
                        System.out.println("Resultado: " + resultado);
                        break;
                    case '*':
                        resultado = num1 * num2;
                        System.out.println("Resultado: " + resultado);
                        break;
                    case '/':
                        if (num2 != 0) {
                            resultado = num1 / num2;
                            System.out.println("Resultado: " + resultado);
                        } else {
                            throw new ArithmeticException("No se puede dividir por 0");
                        }
                        break;
                    default:
                        throw new ExcepcionOperadorInvalido("Operador inválido: " + operador);
                }
            } catch (ExcepcionOperadorInvalido e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                read.nextLine();
            }

            System.out.println("¿Desea salir? (si/no)");
            exit = read.next();
        }

        read.close();
        }
    }
