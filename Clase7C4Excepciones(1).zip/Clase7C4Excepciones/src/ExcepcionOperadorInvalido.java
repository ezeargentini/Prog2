public class ExcepcionOperadorInvalido extends Exception{
    public ExcepcionOperadorInvalido(String mensaje){
        super(mensaje);
    }
}
