public class Main {
    public static void main(String[] args) {
        Lion l1 = new Lion("photo","carne","africa","grande");
        Tiger t1 = new Tiger("photo","carne","africa","grande");
        Cat c1 = new Cat("photo","balanceado","argentina","pequeño");
        Wolf w1 = new Wolf("photo", "carne","alaska","grande");
        Dog d1 = new Dog("photo","balanceado","argentina","mediano");
        System.out.println("Leon");
        l1.roar();
        l1.makeNoise();
        l1.eat();
        l1.sleep();
        System.out.println();
        System.out.println("Tigre");
        t1.roar();
        t1.makeNoise();
        t1.eat();
        t1.sleep();
        System.out.println();
        System.out.println("Gato");
        c1.roar();
        c1.makeNoise();
        c1.eat();
        c1.sleep();
        System.out.println();
        System.out.println("Lobo");
        w1.roar();
        w1.makeNoise();
        w1.eat();
        w1.sleep();
        System.out.println();
        System.out.println("Perro");
        d1.roar();
        d1.makeNoise();
        d1.eat();
        d1.sleep();

    }
}