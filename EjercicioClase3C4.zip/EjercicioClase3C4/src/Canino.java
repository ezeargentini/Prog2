public abstract class Canino extends Animal{
    public Canino(String photo, String food, String location, String size) {
        super(photo, food, location, size);
    }

    @Override
    public void roar() {
        System.out.println("Grrr");
    }
}
