public class Lion extends Feline {
    public Lion(String photo, String food, String location, String size) {
        super(photo, food, location, size);
    }

    @Override
    public void eat() {
        System.out.println("El leon esta comiendo");
    }

    @Override
    public void makeNoise() {
        System.out.println("El leon esta haciendo ruido");
    }
}
