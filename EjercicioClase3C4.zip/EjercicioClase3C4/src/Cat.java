public class Cat extends Feline {
    public Cat(String photo, String food, String location, String size) {
        super(photo, food, location, size);
    }

    @Override
    public void eat() {
        System.out.println("El gato esta comiendo");
    }

    @Override
    public void makeNoise() {
        System.out.println("El gato esta haciendo ruido");
    }
    public void vaccinate(){
        System.out.println("Se vacuno el gato");
    }
}
