public class Wolf extends Canino {
    public Wolf(String photo, String food, String location, String size) {
        super(photo, food, location, size);
    }

    @Override
    public void eat() {
        System.out.println("El lobo esta comiendo");
    }

    @Override
    public void makeNoise() {
        System.out.println("El lobo esta haciendo ruido");
    }

}
