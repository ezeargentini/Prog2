public class Dog extends Canino {
    public Dog(String photo, String food, String location, String size) {
        super(photo, food, location, size);
    }

    @Override
    public void eat() {
        System.out.println("El perro esta comiendo");
    }

    @Override
    public void makeNoise() {
        System.out.println("el perro esta haciendo ruido");
    }
    public void vaccinate(){
        System.out.println("Se vacuno el perro");
    }
    public void goForWalk(){
        System.out.println("El perro salio a pasear");
    }
}
