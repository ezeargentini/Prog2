public class Main {
    public static void main(String[] args) {
        Equipo equipo = new Equipo();
        Jugador jugador1 = new Jugador("Jeronimo","Central",2);
        Jugador jugador2 = new Jugador("Ezequiel", "Mediocampista", 8);
        Jugador jugador3 = new Jugador("Mauro", "Delantero",9);
        equipo.getJugadores().add(jugador1);
        equipo.getJugadores().add(jugador2);
        equipo.getJugadores().add(jugador3);


        for (Jugador jugador : equipo.getJugadores()){
            System.out.println(jugador.toString());
        }
    }
}