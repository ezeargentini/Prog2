import java.util.ArrayList;
import java.util.Iterator;

public class Equipo implements Iterable<String>{
    private ArrayList<Jugador> jugadores;

    public Equipo() {
        this.jugadores = new ArrayList<>();
    }

    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    @Override
    public Iterator<String> iterator() {
        return new Iterator<String>() {
            private int indice = 0;
            private Iterator<Jugador> jugadorIterator = jugadores.iterator();

            @Override
            public boolean hasNext() {
                return jugadorIterator.hasNext();
            }

            @Override
            public String next() {
                return jugadorIterator.next().getNombre();
            }
        };
    }


}
