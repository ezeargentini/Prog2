package Agregacion;

import java.util.ArrayList;
import java.util.Scanner;

public class Department {
    private ArrayList<Employee> employees;
    private String name;

    public Department() {
    }

    public Department(String name) {
        this.employees = new ArrayList<Employee>();
        this.name = name;
    }

    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addEmployee(Employee employee){
        employees.add(employee);
    }

    public void deleteEmployee(){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese el nombre del empleado que desea eliminar");
        String delete = read.nextLine();
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getName().equalsIgnoreCase(delete)){
                employees.remove(employees.get(i));
                System.out.println("Empleado eliminado con exito!");
            }
        }
    }

    public void displayEmployee(){
        System.out.println("--------------------------------------------");
        System.out.println("Lista de empleados del departamento " + name);
        for (int i = 0; i < employees.size(); i++) {
            System.out.println("Nombre: " + employees.get(i).getName());
        }
        System.out.println("--------------------------------------------");
    }
}
