package Agregacion;

import java.util.ArrayList;
import java.util.Scanner;

public class Company {
    private ArrayList<Department> departments;
    private String name;

    public Company() {
    }

    public Company(String name) {
        this.departments = new ArrayList<Department>();
        this.name = name;
    }

    public ArrayList<Department> getDepartments() {
        return departments;
    }

    public void setDepartments(ArrayList<Department> departments) {
        this.departments = departments;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addDepartment(Department department){
        departments.add(department);
    }

    public void deleteApartment(){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese el nombre del departamento que desea eliminar");
        String delete = read.nextLine();
        for (int i = 0; i < departments.size(); i++) {
            if (departments.get(i).getName().equalsIgnoreCase(delete)){
                departments.remove(departments.get(i));
            }
        }
    }

    public void displayDepartment(){
        System.out.println("--------------------------------------------");
        System.out.println("Lista de departamentos: ");
        for (int i = 0; i < departments.size(); i++) {
            System.out.println("Nombre: " + departments.get(i).getName());
        }
        System.out.println("--------------------------------------------");
    }


}
