package AsociacionBidireccional;

import java.util.ArrayList;

public class Persona {
    private ArrayList<Libro> libros;
    private String nombre;

    public Persona() {
    }

    public Persona(String nombre) {
        this.libros = new ArrayList<>();
        this.nombre = nombre;
    }

    public ArrayList<Libro> getLibros() {
        return libros;
    }

    public void setLibros(ArrayList<Libro> libros) {
        this.libros = libros;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void agregarLibro(Libro l1){
        libros.add(l1);
    }
    public void verLibros(){
        System.out.println("La persona tiene "+ libros.size() + " libros");
        System.out.println("La lista de libros es: ");
        for (int i = 0; i < libros.size(); i++) {
            System.out.println("Titulo: " + libros.get(i).getTitulo());
        }
    }
}
