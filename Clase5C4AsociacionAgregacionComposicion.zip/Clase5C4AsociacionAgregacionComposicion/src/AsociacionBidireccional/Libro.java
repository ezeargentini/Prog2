package AsociacionBidireccional;

import java.util.ArrayList;

public class Libro {
    private String titulo;
    private ArrayList<Persona> personas;

    public Libro() {
    }

    public Libro(String titulo) {
        this.titulo = titulo;
        this.personas = new ArrayList<>();
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    public void añadirPersona(Persona p1){
        personas.add(p1);
    }

    public void verPersonas(){
        System.out.println("EL libro lo tiene las siguientes personas (" + personas.size() + ")");
        for (int i = 0; i < personas.size(); i++) {
            System.out.println("Nombre: " + personas.get(i).getNombre());
        }
    }
}
