package Composicion;

import java.util.ArrayList;
import java.util.Scanner;

public class House {
    private ArrayList<Door> doors;

    public House() {
        this.doors = new ArrayList<>();
        this.doors = addDoors();
    }

    public ArrayList<Door> addDoors(){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese cuantas puertas tiene la casa");
        int door = read.nextInt();
        read.nextLine();
        for (int i = 0; i < door; i++) {
            Door d1 = new Door();
            System.out.println("Ingrese el material de la puerta " + (i+1));
            d1.setMaterial(read.nextLine());
            doors.add(d1);
        }
        return doors;
    }

    public void displayDoors(){
        System.out.println("La casa tiene las siguientes puertas");
        for (int i = 0; i < doors.size(); i++) {
            System.out.println((i+1) + ". " + doors.get(i).getMaterial());
        }
    }
}
