import Agregacion.Company;
import Agregacion.Department;
import Agregacion.Employee;
import AsociacionBidireccional.Libro;
import AsociacionBidireccional.Persona;
import AsociacionUnidireccional.Estudiante;
import AsociacionUnidireccional.Universidad;
import Composicion.House;

public class Main {
    public static void main(String[] args) {
        Main main = new Main();
        System.out.println("Ejercicio agregacion unidireccional");
        main.asociacionUnidireccional(); //Ejercicio agregacion unidireccional
        System.out.println("Ejercicio agregacion bidireccional");
        main.associacionBidireccional(); //Ejercicio agregacion bidireccional
        System.out.println("Ejercicio agregacion");
        main.agregacion(); //Ejercicio agregacion
        System.out.println("Ejercicio composicion");
        main.composicion(); // Ejercicio composicion
    }

    public void asociacionUnidireccional(){
        //Asociacion Unidireccional
        Universidad universidad = new Universidad("Universidad Tecnologica Nacional");
        Estudiante estudiante = new Estudiante("Jeronimo", universidad);
        estudiante.verUniversidad();
        estudiante.cambiarUniversidad();
        estudiante.verUniversidad();
    }

    public void associacionBidireccional(){
        //Asociacion Bidireccional
        //Creamos personas
        Persona p1 = new Persona("Jeronimo");
        Persona p2 = new Persona("Felipe");
        Persona p3 = new Persona("Cortez");
        //Creamos libros
        Libro l1 = new Libro("Libro 1");
        Libro l2 = new Libro("Libro 2");
        //Agregamos libros utilizando el metodo
        p1.agregarLibro(l1);
        p1.agregarLibro(l2);
        p2.agregarLibro(l1);
        p3.agregarLibro(l2);
        //Añadimos personas utilizando el metodo
        l1.añadirPersona(p1);
        l1.añadirPersona(p2);
        l1.añadirPersona(p3);
        l2.añadirPersona(p1);
        l2.añadirPersona(p2);
        //Mostramos las personas con el metodo
        p1.verLibros();
        p2.verLibros();
        p3.verLibros();
        //Mostramos las personas con el metodo
        l1.verPersonas();
        l2.verPersonas();
    }

    public void agregacion(){
        //Agregacion
        //Creamos una empresa
        Company company = new Company("Coca cola");

        //Creamos departamentos
        Department department = new Department("Produccion");
        Department department1 = new Department("Ventas");
        Department department2 = new Department("Envios");

        //Creamos empleados produccion
        Employee employee =  new Employee("Operario de maquina","Luis");
        Employee employee1 = new Employee("Encargado","Martin");
        Employee employee2 = new Employee("Operario","Jeronimo");

        //Creamos empleados de Ventas
        Employee employee3 = new Employee("Tesorero","Florencia");
        Employee employee4 = new Employee("Atencion al cliente", "Franco");
        Employee employee5 =  new Employee("Atencion al cliente", "Geronimo");

        //Creamos empleados para envios
        Employee employee6 = new Employee("Chofer", "Mauro");
        Employee employee7 = new Employee("Ayudante","Franco");

        //Añadimos los empleados a los departamentos
        //Produccion
        department.addEmployee(employee);
        department.addEmployee(employee1);
        department.addEmployee(employee2);

        //Ventas
        department1.addEmployee(employee3);
        department1.addEmployee(employee4);
        department1.addEmployee(employee5);

        //Envios
        department2.addEmployee(employee6);
        department2.addEmployee(employee7);

        //Mostramos empleados
        department.displayEmployee();
        department1.displayEmployee();
        department2.displayEmployee();

        //Eliminamos un empleado a envios
        department2.deleteEmployee();

        //Volvemos a mostrar para verificar que se elimino correctamente
        department2.displayEmployee();

        //Añadimos los departamentos a la compañia
        company.addDepartment(department);
        company.addDepartment(department1);
        company.addDepartment(department2);

        //Mostramos departamentos
        company.displayDepartment();

        //Eliminamos departamento
        company.deleteApartment();

        //Volvemos a mostrar para verificar que se eelimino correctamente
        company.displayDepartment();

        //Mostramos el cargo de un empleado
        employee5.displayPosition();
    }

    public void composicion(){
        /* Composicion */
        House house = new House();
        house.displayDoors();
    }
}