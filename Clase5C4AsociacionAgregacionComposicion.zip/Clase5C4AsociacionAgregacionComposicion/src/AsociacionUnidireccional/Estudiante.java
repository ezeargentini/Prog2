package AsociacionUnidireccional;

import java.util.Scanner;

public class Estudiante {
    private String nombre;
    private Universidad universidad;

    public Estudiante() {
    }

    public Estudiante(String nombre, Universidad univeridad) {
        this.nombre = nombre;
        this.universidad = univeridad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Universidad getUniversidad() {
        return universidad;
    }

    public void setUniversidad(Universidad universidad) {
        this.universidad = universidad;
    }

    public void cambiarUniversidad(){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese el nombre de la nueva universidad");
        universidad.setNombre(read.nextLine());
        System.out.println("La universidad se modifico exitosamente!!!!");
        System.out.println("_------------------_");
    }

    public void verUniversidad(){
        System.out.println("La universidad del estudiante " + nombre + " es " + universidad.getNombre());
    }
}
