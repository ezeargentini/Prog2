package Class;

public class Wizard extends BaseCharacter {
    private String power;

    public Wizard(int level, String name, float hitPoints, String power) {
        super(level, name, hitPoints);
        this.power = power;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    @Override
    public float defend(int harm) {
        if(power.equalsIgnoreCase("Barrier of shadows")){
            return harm - 10;
        } else if (power.equalsIgnoreCase("Frost Nova")) {
            return harm - 20;
        } else if (power.equalsIgnoreCase("Temporal distortion")) {
            return harm - 30;
        }
        return harm;
    }

    @Override
    public String toString() {
        return super.toString() +  "Wizard{" +
                "power='" + power + '\'' +
                '}';
    }
}
