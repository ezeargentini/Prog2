package Class;

public interface Character {
    public int attack();
    public float defend(int harm);

}
