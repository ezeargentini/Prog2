package Class;

public abstract class BaseCharacter implements Character {
    private int level;
    private String name;
    private float hitPoints;

    public BaseCharacter() {
    }

    public BaseCharacter(int level, String name, float hitPoints) {
        this.level = level;
        this.name = name;
        this.hitPoints = hitPoints;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getHitPoints() {
        return hitPoints;
    }

    public void setHitPoints(float hitPoints) {
        this.hitPoints = hitPoints;
    }

    @Override
    public int attack() {
        if (level == 1) {
            return 50;
        } else if (level >= 2 && level <= 4) {
            return 150;
        } else if (level >= 5) {
            return 250;
        }else {
            return 1;
        }
    }

    @Override
    public String toString() {
        return "BaseCharacter{" +
                "level=" + level +
                ", name='" + name + '\'' +
                ", hitPoints=" + hitPoints +
                '}';
    }
}
