package Class;

public class Rogue extends BaseCharacter {
    private String gadgets;

    public Rogue(int level, String name, float hitPoints, String gadgets) {
        super(level, name, hitPoints);
        this.gadgets = gadgets;
    }

    public String getGadgets() {
        return gadgets;
    }

    public void setGadgets(String gadgets) {
        this.gadgets = gadgets;
    }

    @Override
    public float defend(int harm) {
        if (gadgets.equalsIgnoreCase("Shadow hook")){
            return harm - 10;
        } else if (gadgets.equalsIgnoreCase("Smoke cloud")) {
            return harm - 20;
        } else if (gadgets.equalsIgnoreCase("Throwing Daggers")) {
            return harm - 30;
        }
        return harm;
    }

    @Override
    public String toString() {

        return super.toString() + "Rogue{" +
                "gadgets='" + gadgets + '\'' +
                '}';
    }
}
