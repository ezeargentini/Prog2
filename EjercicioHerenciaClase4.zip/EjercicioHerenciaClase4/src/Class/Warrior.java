package Class;

public class Warrior extends BaseCharacter {
    private String weapon;

    public Warrior(int level, String name, float hitPoints, String weapon) {
        super(level, name, hitPoints);
        this.weapon = weapon;
    }

    public String getWeapon() {
        return weapon;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }

    @Override
    public float defend(int harm) {
        if(weapon.equalsIgnoreCase("sword")){
            return harm - 10;
        } else if (weapon.equalsIgnoreCase("axe")) {
            return harm - 20;
        } else if (weapon.equalsIgnoreCase("hammer")) {
            return harm - 30;
        }
        return harm;
    }

    @Override
    public String toString() {
        return super.toString() +  "Warrior{" +
                "weapon='" + weapon + '\'' +
                '}';
    }
}
