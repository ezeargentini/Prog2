import Class.Warrior;
import Class.Rogue;
import Class.Wizard;

public class Main {
    public static void main(String[] args) {
        Rogue rogue = new Rogue(3,"Rogue", 1000, "Shadow hook");
        Warrior warrior = new Warrior(1,"Warrior", 1000, "Sword");
        Wizard wizard = new Wizard(5,"Wizard",1000,"Barrier of shadows");
        System.out.println("EL mago ataca a un picaro");
        System.out.println("Puntos de vida picaro: " + rogue.getHitPoints()+  " - "  + rogue.defend(wizard.attack()));
        rogue.setHitPoints(rogue.getHitPoints() - rogue.defend(wizard.attack()));
        System.out.println("Puntos de vida picaro: " + rogue.getHitPoints());
        System.out.println();
        System.out.println("********************************");
        System.out.println();
        System.out.println("EL picaro ataca a un mago");
        System.out.println("Puntos de vida mago: " + wizard.getHitPoints()+  " - "  + wizard.defend(rogue.attack()));
        wizard.setHitPoints(wizard.getHitPoints() - wizard.defend(rogue.attack()));
        System.out.println("Puntos de vida mago: " + wizard.getHitPoints());
        System.out.println();
        System.out.println("********************************");
        System.out.println();
        System.out.println("EL picaro ataca a un guerrero");
        System.out.println("Puntos de vida guerrero: " + warrior.getHitPoints()+  " - "  + warrior.defend(rogue.attack()));
        warrior.setHitPoints(warrior.getHitPoints() - warrior.defend(rogue.attack()));
        System.out.println("Puntos de vida guerrero: " + warrior.getHitPoints());

    }
}
