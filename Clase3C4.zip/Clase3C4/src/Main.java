public class Main {
    public static void main(String[] args) {
        FullTimeEmployee e1 = new FullTimeEmployee(1,"Cinthia",1500,700);
        System.out.println("El salario del trabajador " + e1.getName() + " es de: " + e1.calculateSalary());
        PartTimeEmployee p1 = new PartTimeEmployee(2,"Jeronimo",0,26, 570);
        System.out.println("El salario del empleado " + p1.getName() + " es de: " + p1.calculateSalary());
    }
}