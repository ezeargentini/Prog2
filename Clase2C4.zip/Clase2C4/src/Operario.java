public class Operario extends Empleado{
    private int documento;
    public Operario() {
    }

    public Operario(String nombre, int documento) {
        super(nombre);
        this.documento = documento;
    }

    public int getDocumento() {
        return documento;
    }

    public void setDocumento(int documento) {
        this.documento = documento;
    }

    public boolean esValido(int documento){
        int longitud = String.valueOf(documento).length();
        if (longitud == 7 || longitud == 8 ){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public String toString() {
        return "Los datos del operario son" +
                super.toString() +
                "Documento" + documento ;
    }
}
