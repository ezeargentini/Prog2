public class Oficial extends Operario{
    private int edad;
    public Oficial() {
    }

    public Oficial(String nombre, int documento, int edad) {
        super(nombre, documento);
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void jubilacion(int edad){
        System.out.println("Los oficiales se jubilan a los 65 años");
        if(edad <= 65) {
            System.out.println("Hola! " + getNombre() + " te quedan " + (65 - edad) + " años para jubilarte");
        }else{
            System.out.println("Hola! " + getNombre() + "Ya esta jubilado!");
        }
    }

    @Override
    public String toString() {
        return super.toString() +
                "Edad: " + edad;
    }
}
