public class Tecnico extends Operario{
    private int legajo;
    public Tecnico() {
    }

    public Tecnico(String nombre, int documento, int legajo) {
        super(nombre, documento);
        this.legajo = legajo;
    }

    public void asignarTarea(String tarea){
        System.out.println("Se le asigno la tarea "+ tarea + " a " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() +
                "Legajo: " + legajo;
    }
}
