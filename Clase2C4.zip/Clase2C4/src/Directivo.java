public class Directivo extends Empleado{
    private String departamento;
    public Directivo() {
    }

    public Directivo(String nombre, String departamento) {
        super(nombre);
        this.departamento = departamento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public void empleadoACargo(String departamento){
        if(departamento.equalsIgnoreCase("ventas")){
            System.out.println("Usted tiene 30 empleados a cargo");
        }else if(departamento.equalsIgnoreCase("produccion")){
            System.out.println("Usted tiene 12 empleados a cargo");
        }else if(departamento.equalsIgnoreCase("administracion")){
            System.out.println("Usted tiene 20 empleados a cargo");
        }else{
            System.out.println("Su departameno aun no registra empleados");
        }
    }

    @Override
    public String toString(){
        return "Los datos del directivo son" +
                super.toString() +
                "Departamento: " + departamento;
    }
}
