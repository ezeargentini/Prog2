public class Main {
    public static void main(String[] args) {
        Operario op =  new Operario("Jeronimo", 44820614);
        Oficial of = new Oficial("Felipe", 44625800,21);
        Tecnico tec = new Tecnico("Mauro",44635236,1234);
        Directivo dir = new Directivo("Ezequiel", "ventas");
        System.out.println(op.toString());
        System.out.println("Documento valido: " + op.esValido(of.getDocumento()));
        System.out.println(of.toString());
        of.jubilacion(of.getEdad());
        System.out.println(tec.toString());
        tec.asignarTarea("Limpieza");
        System.out.println(dir.toString());
        dir.empleadoACargo(dir.getDepartamento());

    }
}