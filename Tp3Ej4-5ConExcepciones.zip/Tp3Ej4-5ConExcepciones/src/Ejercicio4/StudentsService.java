package Ejercicio4;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class StudentsService {
    ArrayList <Student> students = new ArrayList<>();
    public void addStudent(){
        Scanner read = new Scanner(System.in);
        Student student = new Student();
        System.out.println("Ingrese el nombre: ");
        try{
            student.setName(read.nextLine());
            System.out.println("Ingrese la edad: ");
            student.setAge(read.nextInt());
            System.out.println("Ingrese la nota: ");
            student.setNote(read.nextDouble());
            students.add(student);
        }catch (InputMismatchException e){
            System.out.println("Error edad y/o nota se deben ingresar numericamente");
        }

    }

    public void displayStudents() {
        System.out.println("--- Lista de estudiantes ---");
        for (int i = 0; i < students.size(); i++) {
            System.out.println();
            System.out.println("Estudiante: " + students.get(i).getName().toUpperCase());
            System.out.println("Edad: " + students.get(i).getAge());
            System.out.println("Nota: " + students.get(i).getNote());
        }
    }
    public void averageNotes(){
        int sum = 0;
        double average;
        for (int i = 0; i < students.size(); i++) {
            sum = (int) (sum + students.get(i).getNote());
        }
        try{
            average = sum / students.size();
            System.out.println("EL promedio de nota es de: "+ average);
        }catch (ArithmeticException e){
            System.out.println("No se puede dividir por 0 (La lista de estudiantes esta vacia)");
        }
    }

    public void studentMost(){
        double mostNote = 0;
        Student studentMost = new Student();
        for (int i = 0; i < students.size(); i++) {
            if(mostNote < students.get(i).getNote()){
                mostNote = students.get(i).getNote();
                studentMost = students.get(i);
            }
        }
        System.out.println("El estudiante con mejor nota es: " + studentMost.getName());
        System.out.println("Su nota es: " + studentMost.getNote());
    }

    public void searchStudent(){
        Scanner read = new Scanner(System.in);
        System.out.println("Ingrese el nombre del alumno que desea buscar");
        String name = read.nextLine();
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getName().equalsIgnoreCase(name)){
                System.out.println("Nombre: " + students.get(i).getName());
                System.out.println("Edad: " + students.get(i).getAge());
                System.out.println("Nota: " + students.get(i).getNote());
            }
        }
    }
}
