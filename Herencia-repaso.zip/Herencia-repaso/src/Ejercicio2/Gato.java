package Ejercicio2;

public class Gato extends Animal{
    private String raza;

    public Gato() {
    }

    public Gato(String raza) {
        this.raza = raza;
    }

    public Gato(String nombre, int edad, String genero, String raza) {
        super(nombre, edad, genero);
        this.raza = raza;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    @Override
    public void hacerSonido() {
        super.hacerSonido();
        System.out.println("El gato maulla");
    }

    @Override
    public void informacion() {
        super.informacion();
        System.out.println("Raza: " + raza);
    }
}
