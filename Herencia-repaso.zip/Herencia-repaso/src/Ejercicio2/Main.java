package Ejercicio2;

public class Main {
    public static void main(String[] args) {
        Perro p1 = new Perro("Luna", 13,"Hembra","Labrador");
        Gato g1 = new Gato("Gato", 12,"Macho","Callejero");
        Pajaro pa1 = new Pajaro("Pajaro", 3, "Hembra", "Loro");
        p1.hacerSonido();
        p1.informacion();
        g1.hacerSonido();
        g1.informacion();
        pa1.hacerSonido();
        pa1.informacion();
    }
}
