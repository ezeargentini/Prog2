package Ejercicio2;

public class Perro extends Animal{
    private String raza;

    public Perro() {
    }

    public Perro(String nombre, int edad, String genero, String raza) {
        super(nombre, edad, genero);
        this.raza = raza;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    @Override
    public void hacerSonido() {
        super.hacerSonido();
        System.out.println("El perro ladra");
    }

    @Override
    public void informacion() {
        super.informacion();
        System.out.println("Raza: " + raza);
    }
}
