package Ejercicio2;

public class Pajaro extends Animal{
    private String especie;

    public Pajaro() {
    }

    public Pajaro(String nombre, int edad, String genero, String especie) {
        super(nombre, edad, genero);
        this.especie = especie;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    @Override
    public void hacerSonido() {
        super.hacerSonido();
        System.out.println("Los pajaros cantan");
    }

    @Override
    public void informacion() {
        super.informacion();
        System.out.println("Especie: " + especie);
    }
}
