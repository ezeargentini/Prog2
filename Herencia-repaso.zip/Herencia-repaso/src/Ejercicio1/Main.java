package Ejercicio1;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();
        Coche c1 = new Coche("Rojo",4,220,110);
        Camioneta ca1 = new Camioneta("Verde",4,220,110,1500);
        Bicicleta b1 = new Bicicleta("Rojo",0,"urbana");
        Motocicleta m1 = new Motocicleta("Rojo",2,"urbana",150,110);
        vehiculos.add(c1);
        vehiculos.add(ca1);
        vehiculos.add(b1);
        vehiculos.add(m1);
        c1.catalogar(vehiculos,c1);
        ca1.catalogar(vehiculos,ca1);
        b1.catalogar(vehiculos,b1);
        m1.catalogar(vehiculos,m1);

    }
}
