package Ejercicio1;

import java.util.ArrayList;

public class Camioneta extends Coche{
    private int carga;

    public Camioneta() {
    }

    public Camioneta(String color, int ruedas, int velocidad, int cilindrada, int carga) {
        super(color, ruedas, velocidad, cilindrada);
        this.carga = carga;
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        this.carga = carga;
    }

    @Override
    public void catalogar(ArrayList<Vehiculo> vehiculos, Vehiculo v1) {
        super.catalogar(vehiculos, v1);
        System.out.println("Carga: " + carga);
    }
}
