package Ejercicio1;

import java.util.ArrayList;

public class Coche extends Vehiculo{
    private int velocidad;
    private int cilindrada;

    public Coche() {
    }

    public Coche(String color, int ruedas, int velocidad, int cilindrada) {
        super(color, ruedas);
        this.velocidad = velocidad;
        this.cilindrada = cilindrada;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    @Override
    public void catalogar(ArrayList<Vehiculo> vehiculos, Vehiculo v1){
        super.catalogar(vehiculos,v1);
        System.out.println("Velocidad: " + velocidad+
                " Cilindrada: " + cilindrada);
    };

}
