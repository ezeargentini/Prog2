package Ejercicio1;

import java.util.ArrayList;

public class Vehiculo {
    private String color;
    private int ruedas;

    public Vehiculo() {
    }

    public Vehiculo(String color, int ruedas) {
        this.color = color;
        this.ruedas = ruedas;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getRuedas() {
        return ruedas;
    }

    public void setRuedas(int ruedas) {
        this.ruedas = ruedas;
    }

    public void catalogar(ArrayList<Vehiculo> vehiculos, Vehiculo v1) {
        int contRuedas = 0;
        System.out.println("Color: " + color +
                " Ruedas: " + ruedas);

        if (v1 instanceof Coche) {
            System.out.println("Tipo de vehiculo: Coche");
        } else if (v1 instanceof Camioneta) {
            System.out.println("Tipo de vehiculo: Camioneta");
        } else if (v1 instanceof Bicicleta) {
            System.out.println("Tipo de vehiculo: Bicicleta");
        } else if (v1 instanceof Motocicleta) {
            System.out.println("Tipo de vehiculo: Motocicleta");
        } else {
            System.out.println("El vehiculo no tiene ruedas");
        }
        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i).ruedas > 0) {
                contRuedas++;
            }
        }
        System.out.println("Hay " + contRuedas + " vehiculos con ruedas");
    }
}
