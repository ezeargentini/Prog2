package Ejercicio1;

import java.util.ArrayList;

public class Motocicleta extends Bicicleta{
    private int velocidad;
    private int cilindrada;

    public Motocicleta() {
    }

    public Motocicleta(String color, int ruedas, String tipo, int velocidad, int cilindrada) {
        super(color, ruedas, tipo);
        this.velocidad = velocidad;
        this.cilindrada = cilindrada;
    }
    @Override
    public void catalogar(ArrayList<Vehiculo> vehiculos, Vehiculo v1){
        super.catalogar(vehiculos, v1);
        System.out.println("Velocidad: " + velocidad+
                "Cilindrada: " + cilindrada);
    };
}
