package EjercicioClase1C4;

public class Camion extends Vehiculo {
    private float carga;
    public Camion() {
    }
    public Camion(String duenio, int puertas, int ruedas, float carga) {
        super(duenio, puertas, ruedas);
        this.carga = carga;
    }

    public float getCarga() {
        return carga;
    }

    public void setCarga(float carga) {
        this.carga = carga;
    }

    @Override
    public void caracteristicas() {
        if(carga>=1000){
            System.out.println("El camion está sobrecargado.");
        }else{
            System.out.println("Puede continuar.");
        }
    }

}
