package EjercicioClase1C4;

public class Main {
    public static void main(String[] args) {
        Auto a1 = new Auto("Jeronimo",4,4,true);
        Camion c1 = new Camion("Felipe",4,8,10000);
        a1.caracteristicas();
        c1.caracteristicas();
    }
}