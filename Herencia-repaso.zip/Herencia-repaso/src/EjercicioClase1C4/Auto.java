package EjercicioClase1C4;

public class Auto extends Vehiculo {
    private boolean descapotable;

    public Auto() {
    }
    public Auto(String duenio, int puertas, int ruedas, boolean descapotable) {
        super(duenio, puertas, ruedas);
        this.descapotable = descapotable;
    }

    public boolean isDescapotable() {
        return descapotable;
    }

    public void setDescapotable(boolean descapotable) {
        this.descapotable = descapotable;
    }

    @Override
    public void caracteristicas() {
        System.out.println("Puertas: "+this.getPuertas());
        System.out.println("Ruedas: "+this.getRuedas());
        System.out.println("El propietario del auto es "+this.getDuenio());
        if(isDescapotable()){
            System.out.println("El auto es descapotable.");
        }
    }

}
